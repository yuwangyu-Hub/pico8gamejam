--red christmas redemption v1.0
--made by ywy & music by jjk

--修复了搬运礼物时按下射击按键，当礼物放下后会自动射击的bug
--修复了气球爆炸后子弹穿过礼物仍然会有爆炸声音的bug
--修复了按键的问题
--封面
pic1="`ツ`yhテhテhテhたbch★hしbdhˇhきibbchsich⬇️hえibhbbahyidh○hg`nh✽idhaiabahえhf`ph▒ibhbidbahb`ahいhd`th}ibhbidbbhc`chp`dhgiahbichxhd`cgn`ch{ibhbiebahd`abchkbh`ahhiahdibhvhd`cgn`chyiahcidhbbahe`abbhjbi`ahjibhdichshd`ogb`chzidhciabahe`abbhhbk`ahkidhbiahbichphe`cgc`fgd`chwiehbicbahfbbhgbb`khmiehbiahcibhnhe`cge`bge`chviahcigbahgbbhdbc`ahyighaibhcibhlhe`fgf`fhtiahbiibahgbdhabb`bhjgahagahagchagahagahgikhcibhjhd`fgh`fhqibhaikbahgbf`ahigrhcimhcibhhhd`bgg`bgg`bhpibhaikbahgbd`chfgahaguhbgaiihaichdibhfhd`cgd`fge`bhnichaikgabahfbd`ahgg|ijhbichdiahehd`igb`ihmichailgabahe`abc`aheg█ikhbibhdiahdhd`cgn`chliahbingabahe`aba`ahdgahagaoag○imhbiahhhd`cgn`chkiahaiogabahe`abbhb`aoeg▒inhfiahbhd`igb`ihjiahaipgabahe`abaha`aohg█iphbiahciahd`bgp`bhhibhaipgabahe`abahaoigcoag~iphciahbhd`bgo`chgiahbiqgahfbaokgcoag~irhciahd`shgiahaisgahfokgcoag○ishc"
pic2="`ツ`yhd`bgo`chgiahbiqgahfbaokgcoag~irhciahd`shgiahaisgahfokgcoag○ishche`rhfiahaisgbhebaokgboag█ithbhd`thbiahaiahaitgahf`aomg▒ivhd`bgb`jgd`bhaiahaiahaiugahebagaolg🐱ivhd`bgc`agd`agg`biahaiahaiugbhe`agaolgdoag~iuhd`cgb`agd`age`dhaixgbhe`agaolgcoag○iuhd`hgb`dgb`diygbhegaoagaoagaojgaoag█iuhd`ggb`egb`diygbhegaoagbolgvobgaoggaiuhd`bgc`agb`cgb`agd`bixgbhe`agaoagaolgtoc`cdb`agboagaivhd`bgc`agd`agb`agd`bixgbhd`aiagcolgqoc`ddb`adbgciwhd`cgb`agd`agb`agb`dixgbhbba`aibgcoagaoagaoigboigaoaga`aoadb`gdc`agbiwhd`cgb`cgb`agb`agb`dixgbhaba`aidgcoagaom`fdb`bbada`eda`bda`bdcgcivhd`cgb`agc`bgb`agb`dixgbhaba`aidgboagboj`cda`hbbdb`bdb`adhgbiagaiuhd`cgb`agc`bgg`biy`abb`aidgdoh`cdc`hbbdd`bdcbbdegcivhd`cgc`agc`agg`biz`agbiegcog`agadd`ddb`bdabadf`adabbdeocgbivhd`bgd`agd`iiygaobgcicgdod`cdagadb`adeba`adabaddoadaoa`adfoegbivhd`bgc`agc`agh`bixgaocgcidgcob`cgcdaga`adcbcdbbadfobdeoadbodgbivhd`bgc`agb`cgf`cixgcoagcidgc`dgedaoadnoddbojgaivhd`siygbocgbidgb`cgfdaoadpoogaivhe`qi{gaocgbif`agc`agddkbadcbadboddaogdboagbiuhe`qi}ocif`aga`cgfdibadcba`adcobda`adboadfoagbiuhd`ggc`ii░`ddaga`agfdaoadcbcdcba`adbiadc`aia`adaocdcobgbiuhd`cgj`agc`ci✽`agada`adaggdaoadabcddba`ada`bdb`adcoadaocdbobgbiu`テ`テ"
pic3="`ツ`yhd`cgn`ciwmbimgada`adaghdbbadeba`bdhogdaoagciuhd`ggc`bgc`eiwmbimgaddggdhba`ada`cdc`aociaoegaoagbiuhd`bgp`biumaia`bingaddgfdagadagadcba`add`fgdoegciuhd`bgp`biumc`amagb`aijgadbgadaggdagadagadb`add`agriuhd`fgc`kitmagemaga`aikgadbgadagedagcdagadcgviuhd`dge`dgc`diega`aijgh`cimdcgkdbggdcob`aglithd`bgn`didgama`biegh`dmdimdcgp`cbf`doaggithd`bgn`didmaga`bibgh`dmhilddgn`bbeobdaobdb`aoageiuhd`bgc`agg`gidmaga`bgg`emjil`adbgn`bba`adcog`aoagfiuhd`fgc`fgb`ciagk`emj`amagail`aia`agm`ada`add`edaobdaiagfiuhd`fgc`fgb`ciagg`fmfgbmc`bmcga`ailgmdb`ada`bda`eda`aoadcgeivhe`egk`ciagama`hmgge`bma`cmbga`aij`aiagl`adb`adb`fdaoadaoadagfivhf`egi`cicfa`bmb`amggg`amb`emaga`aikgn`adc`hoa`aghivhf`pidga`bmhgbfbgc`bmbga`embgbik`bgl`ada`cda`ada`adagjiwhf`qicga`bmegcfbgc`bmbgc`dmcgeijg▒ivhe`siagfmagcfbgd`amcgcmb`amfgaddoaigg▒iwhe`cgb`bgj`bgjfagd`bmbgc`bmb`ama`cfamagadeoaifgbdbg~ivhe`cgc`agi`cgb`cgg`dmbgb`cmcgama`dfamadeobidgcdbg}iwhe`bgd`dga`bga`mgcma`cmagc`ama`amdgama`dfama`adeoaidgddbg{ixhe`bgb`cgj`kgbfagema`amb`amcgbma`cmc`adeoaicgcda`bdbgzixhe`agb`dgb`aga`bga`agb`kgfma`amc`amagdmefamb`adeobgc`dda`adbgxixhahe`age`agb`aga`bga`agb`lgbfagama`amfgcmbgamfiadeobga`iiadagviyhahe`bgd`agj`lgbfaga`amb`amdgbma`bgamfdfob`abc`bbbgada`adbgtiyhbhe`cgb`xgbfa`amb`amc`amaga`dmf`adaoaddob`abbgbbb`aba`biadbgsbaocivha`テ`テ"
pic4="`ツ`yhe`bgd`bgh`mgb`bma`amc`bma`dmaiamd`bdaoadb`coa`cdaiada`bia`ciadbgpoabaobgaocishbhe`bgd`wgb`cmd`ama`ama`ama`ame`cda`aoa`adcoa`bbada`dbb`diadbgloagaoabaoageobirhahe`cgb`bgj`kgbma`amagamj`bmc`ddboa`addoa`eba`bbcga`biadcgfdagaoagaobbaoaggobiphaiahe`cgb`fgb`ngcmadagcda`bmc`cmbgama`bga`cdaoa`addoa`dba`aib`bbc`biadjodbaoaghoaiohaiahahe`cgc`bgb`agb`agb`cgb`dgdmadcgcdbma`bma`bmcgambga`cdaoa`addoaba`ddaiaga`bia`abb`biadhoebaoaghoaiphaiahe`bgd`agf`agc`bgimagbdcgbdbma`ame`amd`ddboa`cobbb`eba`ebbga`aianbdeobnaoabaoagioabaimhbiahahe`bgc`bgb`agb`cgb`biagfiagdddgadcma`ame`amc`edeobbc`eba`aiaba`bba`dncdbiaobnaoabaoagioabcimhbhe`sihgddbbcgadbma`amh`cdc`bdc`ahbbc`aba`cibga`bia`aba`ciancobnaobbaoagioabbhabaihhaiahdhf`qijgcddbbdbma`amc`bmbdh`doahcbc`cbada`aba`dbbgb`aiancoanaoabaoagioabahbbahabbidhaiahaibhaiahahe`siigbdagaddba`adbma`cmddboadaocddobhebb`dba`aba`aia`aba`aba`dnboanaoabaoagioabbhbbbhabaidhaiahehd`igc`hijgbdbbbdbba`adbme`amadaoadaojhfbboa`aba`cibga`bia`aba`bianbobbaobghoabchcbahabaidhaibhaiahahd`bgp`bijgcdb`abd`adbbb`cfabboadaoihfbcoa`cbada`aba`bbc`cdanaoabaobgaoaggoabchdbahabbibhbibhbhd`bgp`biigddd`bba`abadabb`cmabboadaog`bhgbbob`dba`aba`cbbgb`aiaoabaoagaoagaoageoabehdbahabbhdiahaiahd`bgb`agb`igb`bihgddg`dbb`amcfabaoada`aod`bobhaoagahdbcoa`bbb`abb`cba`aba`aba`abaocgaoagaoagdoabfhdbbhabbiahdhd`dgm`ciggedj`bba`amcfaba`bda`ddbodgbhdbcoa`bbb`bibga`bia`aba`cocgaoagaoagboabahabdhabahebahabbhaiahaiahe`bgc`hgc`bigggdk`ama`cmabadbobdcofgchdbcoa`dba`bba`bbb`agb`bocgaoagaoagaoabahabchabahabahfbahabbhbhe`bgb`bgj`cieggdagadlmcdcolgchdbcob`eba`abc`abc`cocgaoagaobhcbchabahhbahabbhahd`egj`eidgeoagcba`abfdkomgbhebcob`bbb`abc`abb`aia`docgaobhebahabahabahhbbhbhd`bgf`dgf`bidgdoagcdagada`abcdmoj`aobgchdbcoc`bbd`aiaga`dba`coehfbahabahabahkhd`cgc`hgd`bicgdobgddcbadhbcddogdb`bobgchdbcod`abc`aiaga`aba`bbb`dodhgbahabahabahjhe`cgm`cicgcocgedh`bbfdboddc`doagdhdbcoe`abb`aba`aba`cba`bba`cobbahhbahabahabahihe`cgm`cicgcobgcoagbdj`cbcdf`cdb`coagchebcoe`aba`ibb`doabbhhbahabahabahhhf`bgb`igb`biahaibgcocgboa`agbdkba`iddob`boagchebbog`aba`cbb`bba`cgb`bbbhibahabahihf`bgm`bhaibgdocgboa`agbdobadaobdaog`boagdhdbcog`abf`dbc`cbbhqbahb`テ`テ"
pic5="`ツ`yhf`bgb`igb`bhcgdobgcoa`bgbdabbdkbadaofnaoc`boagdhdbcocgaod`abf`bbb`aia`dbbhpbahabahf`qhcgdocgboa`cddbddgbadaofnadaoada`boagdhebbocgboc`abf`aiaga`dgb`bbbhpbahahg`eichaia`ehdgdocgboa`edfbdddbbocdd`dobgchbbahbbbocgcoc`abd`adaga`aba`bbc`cbahobahabahkiehjgdoagaoagboa`idfbhda`hobgchbbahbbcobgdoc`abc`ada`ada`bbb`aia`dbahobahahkifhigdobgcoa`kdi`lobgchbbahbbcocgdoc`abb`adb`biaga`hhpbahlifhhgcodgboa`mdf`mbaoagdhabbhabcocgeoc`aba`ddagada`egb`bhphmifhggcodgboa`█baoagdhabbhbbbodgdod`aba`cdb`ebc`chohmiehhgcocgcoa`█baoagdhabbhbbbocgfoc`abb`hbb`aia`dhnhnibhjgcocgcoaba`○baoagebbhbbaodgfod`abb`abb`ciaga`hhmhoibhhgdobgeoaba`}bboagdhabbhbbbodgfod`abb`abb`aiaga`aba`cgb`chlhpiahhgdocgdoaba`}baobgdhabchabcobghoc`bbb`aba`ada`ada`cbc`dhkhqiahggdocgdoaba`}baobgdhabchabcocgfoagaoc`bbb`gbb`aia`ehjhygdobgeoaba`|bbobgebchabcobgioc`cbb`eiaga`hhjhygdoagaoageoa`|bbobgdhabchabbocgjoc`bbb`aba`biaga`aba`cgb`chihygdocgeoaba`zbcobgdhabgobgaoagiob`cbb`aba`aga`ada`cbc`aba`ahihygdodgdoaba`ybc`aobgebgocgiod`bbc`biada`cbb`aia`aba`bhhhygdocgeobba`xbcocgdhabfodgkoc`bbb`fiaga`eba`bhghybagcocgfobba`vbbhabaobgehabgodgjoc`cbb`diagada`cgb`chghybagcocgfobbb`tbbhabbobgehabhobgjoe`cbb`cgada`cbc`aba`bhfhybbgbodgfobbd`obchabbocgfbhobglod`bbb`gbb`aia`aba`bhfhybcgaodgfodbd`lbchabbocgfbiobglod`cbb`eiaga`hhehybcgbodgeoebphbbbocggbhocgkoeba`dba`cibga`dgaia`bhehybdgaoegeoibfheofggbjobglodbaha`cba`ciaga`daabb`chdhybegaodgfoyggbjobgmodba`laabb`dhd`テ`テ"
pic6="`ツ`yhzbdgaodghovggbjocgmodbaha`jiagaba`fhchzbegaodgiorgjbjobgloebahb`fba`aiagb`cgaia`bhchzbfoegoogglblocglofha`eba`biaba`caabb`bhch{bfoeg○bagabd`abgocgloebahb`kaabbia`chbh{bgoeg~be`bbgocgloebahb`gba`biagaba`bib`ahbh{bgofg{bagabd`cbfodgmoehc`fba`aibga`cgaba`bhah|bgofgybg`cbgocgmodbahc`hiaba`dbb`bhah|bhofgvbh`dbgocgmodbahc`kba`cbb`aha`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ"
--胜利
win1="`ツ`yaleaaカameaaオameaaかiaa…aneaaかiahba♪aとhaiahca😐aoiaaうhbida😐aoiba✽ebnaefamhbiea⬅️anida🐱ednaegamiga⌂aniea█eenaegamibjaida⌂anieabidayegnaegaliia☉anijakcaanegnaegamiajaigarmcarakilalcaaacaalegnaebnbecamibjaidarmfaqaiimancaameenceanaebnaebamiedbakgdabmgaqahimalcaabcdakecnaebnaeanaebnaebamicdbakghmhapakikakcaaacaaoecnaecnaebnaecamibalglmfapaniiahcaabcbaoednaebnaebndeaaygnmfaoanijagcaabcaaacbaahbajednfeeaygnmfaoanidccicahcbaehbajeancebndeeaxgd`bgjmeaoanicceiccbaecdapednaebnaeanaedahjbangd`bgjmcaqanibclamhaajednaebnaefahjbamgrasanibcnalhaaiegnaefawgrasamcaiacqakhaahegnaefaqdaaegl`bgdasamctajhaahegnaefaqdaadfaggnbgc`bgdasamckjbceamhaagehnaeeaqdaacfcgfnbghatalcchbcgjbceamhaagehnaedafjaahdbaadaacfdgoatalcchbclecamhaagegnaebagjaakdbabgbfdgmau"
win2="`ツ`yalcchbcgjbceamhaagehnaedafjaahdbaadaacfdgoatalcchbclecamhaagegnaebagjaakdbabgbfdgmauakcpehajhaahecamjaamdagdfdglauakcnela█jaamgadagdffgiavajcleoa█jaalgbdagefigcaxajciejhbeea█jaamgbdagffkaxamephbeda█jaamgkfjaxalevcaa█jaamgmfgayaleglbelcdaihdapjaangtaqeaagakehlbekcgafhfaojaanguddakeaahakescjadhhanjaangrddamebahajerckaehhamjaaogudbaieeahajepcelbceafhhamjaaoguabdaagecaaecagaienchlbcdaghiakjaaqgtaiebacecagakegcrahhiakjaaqgsaneaaaebagancihbciajhhaahbahjaasgraneaaaebagamcjhbchakhgaahcahjaatgpakedabeaahamccjbcmdaalhjahjaarjaacgoajecaaebajalcdjbckdcamhhaijaaqjaafglaneaaaeaajalcndfanhdncahjaapjbaigiaiecabeaaaebajakcmaadhalnhahjaaojaa|efabebajamcgaediaajbahneakjaanjaa▒ebabebajazdhaajbaxjaamjaa○eeabeaakazdhauhaarjaatdbahegan`テ`テ"
win3="`ツ`ya{dgaejaaohaaqjaaudbagecabebaoaimaaqdgafjaaohaapjaaqdbapebaoahmaaamaapdeaijaanhaaojaardba▒ahmaabmaapdbaljaamhaanjaarjbacdaa~ahmaabmaacmbaajbawjaamhaaljaaojbabjbabdca}afocmaaamaabmaabmajbabjeapjaamhaa{jaaidaa~aeoembaamaacmaaijcanjaalhaazjaa웃aeoemcoaabmaamjbayhaayjaa⌂adocmiapjaayhaacgbarjaaqhbgbhaauadofmaoamaoda웃haacgbaqjaabgbamhcgbhcasacofmaobmaodaこgbalgahcgahcgbaracofmaobmaoda|gca{gbaggbalgahcgahcgbaracoemaohaqgbaigcahgbadgbadgbaegbafgcakgbhcabhbgcaqacoemaogargcahgcahgbadgbadgcadgbafgbalgbhbadgchaaqaboemaogatgbahgdafgcadgbadgdacgbafgbakhagahcadgahcaqaboemaogaejeajgcafgfaegbaegbadgdacgbafgbakhagahbadgahcarabodmaogaejaapgcaegbabgbadgcaegbadgeabgbafgbajhbgahbadhdaracocmaofabjbatgcacgcabgcacgbafgbadgbaagcaagbafgbajhbgahaaehbgbaradoamaogabjbaugbacgbadgbacgbafgbadgbabgeaegcaihcgahaadhbgcajibafaemaofarhbafgcaagcadgcaagcafgbadgbacgdaegbajhcgaaehagcakibafahocaqhbaigeafgeaggbadgbacgdaegbaigahcgaaegdasazhbalgdaggdaggbadgbadgcaegbaigbhbaggbataxhbangcahgcahgbadgbaegbapgbhba}awhaaqgbaigbahgba|hagbhbaqfbaj`テ`テ"
win4="`ツ`yauhba▥gbajhagbhaarfbajathaaいgbaihbgbhaaxibadarhbaせhcgaayibadaqhaa}jaa⌂gahcgaa○aphaa}jaayjbapgahca█aohaakcdanjaa|jaangbhca█anhaahchamjaa~jaachbahgchaa▒alhbaicgeaaljaa○jaaehbaehbgbhaasibalawceeda😐jaafhaadhbgbatibalawccefa😐jaaghaachcgaa🐱awcaehahjba⬅️haachba⬇️ajhbakehcbagjba😐haa♥ajhbakefcda⬅️jbaihaa●axeccia☉jbajhaa✽axebcchdcdbaa⧗haa░aycdhccebba★haa░aycdhbcebda{dbauhaa⬇️aycdhacfbda{ddashaa⬇️azcjbdazdea❎azcibeazdda▤atjaafchbdapgkddgaashba🐱asjaaajaaicdbdangsarhba🐱asjaaajaakcbbcangta●gbanasjaaajaa|gemagqargaabhbaahaakgdam`テ`テ"
win5="`ツ`yasjaaajaa{gdmcgrapgdhiabhaacgdamasjaaajaaygemegraogehmgfalasjaaajaaxgemfgrapgehmgdamatjaazgbmdfbmcgrapgehlaqateaazmffbmdgraogehlaqasecaymlgraogfhkaqasecaymmgraogfhiarariajciaaxmedcmegrapgfhharaphaiahaiajaiahaiahaavmcdfmegpargehharaohaiahaiahaiahaiahaiajaatmddfmefoasgfhfasanhaiajaiahaiahaiahaiahaiajaasmddfmdfpatgfhfaraniajciahaiahaiajaiahaiaasmddfmdfcgbfagbfgaugghdasamiahaiajaiahaiahaiajciahaiaarmcdgmdfcgbfagbfgavgfhdasamhaiahaiahaiahaiahaiajaiahaiahaarmcdfmdfpawgfhbatamiahaiahaiahaiahaiahaiahaiahaiaatmadfmdfdgbfagbfgavgghcasamhaiahaiahaiahaiahaiahaiahaiahaawddmdfdgbfagbffahobangfhbatamiahaiahaiajaiahaiahaiahaiahaiaagfaaafaaodbmcfpagodamgfhbataniahaiajciahaiahaiahaiaagfaabfaarmbfhaoobgaoaabobajgfauanjaiahaiajaiahaiahajahaiahaaefaabfbaafaa⬅️obabodajgdavaojaiahaiahaiahajchaagfdaafba🅾️oagaobakgaaxaphaiahaiahaiahajanaaifda♪obabobaccca○ariahaiahaiaaifbaafda⬅️odadcca▒a🐱faabfaaafaa⌂obgaoaabccabcba○a🐱faabfaa♪obacceaccba|`テ`テ"
win6="`ツ`yaみcaaacea~aふcbabcaaacaaacca~aひcbaacaadcaaacda|aはcaaacaabcaaccaaacaa○aふcba♥aひcaaacca✽aへcaa♥aテ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ"
--失败
lose1="`ツ`y`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`テ`あhi`い`❎hn`▥`ˇhs`∧"
lose2="`ツ`y`❎hn`▥`ˇhs`∧`⬆️hu`ˇ`⧗hw`⬆️`★hy`bfd`♪`➡️hu`chcfagdfa`😐`➡️ht`ehafagffa`⬅️`…hu`efaghfa`⌂`◆fw`dfaghfa`⌂`🅾️fagwfa`cfaghfa`⌂`🅾️fagwfa`cfaghfa`⌂`🅾️fagwfa`dfagffa`⬅️`◆fw`ffagdfa`😐`…fagboogbfa`hfd`♪`◆fagbodacocacodgbfa`▤`◆fagbobgaaaoiaagaobgbfa`▤`🅾️fagdoficofgdfa`❎`♪fagfodieodgffa`∧`😐fagkiegkfa`ˇ`😐faglicglfa`ˇ`♪fagyfa`∧`♪fagjoegjfa`∧`🅾️faghobhcobghfa`❎`◆fbgghabchaggfb`▤`テ`テ"
lose3="`ツ`y`◆fagufa`▤`◆fagufa`▤`…fagsfa`▥`…fagsfa`▥`➡️fagcfagifagcfa`あ`…hbfchafaggfahafchc`▤`◆hhfagefahi`❎`◆hifehk`∧`🅾️h{`ˇ`♪hebahobahf`ˇ`♪hdbahqbahf`⬆️`😐hdbahsbahe`⬆️`😐gdbahsbagdha`⬆️`⬅️gdbahubagd`⬆️`⬅️obgbbahabbhobbhabagbob`⬆️`⬅️oebdhmbdoe`⬆️`😐odbdhmbdod`ˇ`😐odbeeahcichceabeod`ˇ`♪ob`bbdeciaeciaecbd`bob`∧`➡️behaeaiaeciaeahabe`あ`★bdhcichcbd`い`★bdhibd`い`⧗bb`che`cbb`う`テ`テ`テ"
lose4="`ツ`y`テ`テ`テ`テ`テ`テ`⬆️gd`す`pgg`cgb`kgb`igh`lge`⧗`pgg`cgb`egd`agf`egd`cgc`jgg`egb`jgh`hgb`o`sgb`kgl`egb`fgb`igc`cgb`egb`dgb`dgh`hgb`o`sgb`kgb`bgc`cgb`egb`fgb`hgc`dgc`cgc`dgb`ggb`kgb`o`sgb`egb`dgb`cgb`cgb`egb`cge`hgc`egb`cgb`egb`ggb`kgb`o`sgb`egb`dgb`cgb`cgb`egi`igb`fgb`cgb`egb`ggb`kgb`o`sgb`egb`dgb`cgb`cgb`egf`lgb`egc`cgb`egb`ggb`kgb`o`sgb`egb`dgb`cgb`cgb`egb`pgc`dgb`dgb`dgc`ggb`kgb`o`sgb`egb`dgb`cgb`cgb`egc`pgb`cgc`dgb`cgc`hgb`kgb`o`sgb`egb`dgb`cgb`cgb`fgg`kgg`egc`age`ggb`kgb`o`sgb`egb`dgb`hgb`ggf`lge`gge`agd`egb`|`sgb`egb`ngb`●gc`cgc`⬇️`イgb`o`イgb`o`テ`テ`テ`テ`テ"
--失败/企鹅胜利
lose_qiewin1="`ツ`y`テ`⬇️gr`た`|g▒`く`xg웃`え`tg…`あ`qg∧`❎`ngう`⬆️`lg▒kcg}`➡️`jg{kdgckeg}`…`hg|kfgakcgakcg~`🅾️`gg|kcgbkegckbg○`♪`eg~kcgckcgckcg█`😐`dg█kcgckbgckbg🐱`⬅️`cg🐱kcgbkbgbkcg⬇️`⌂`bg⬇️bakcbakbbakcbag░`웃`ag▒bcknbag⬇️`♥g}bedekkdabdg▒`●g|bbdgkmddbcg█`✽g|bbdabdkdibddickdbadcbag▒`░g|bbddkdbciebckddcbag🐱`⬇️g|bbddkddcbedckddcbag⬇️`🐱giabgqbcdckddeiadekddbbcg⬇️`▒ggafgpbadabckddeiadekccbbacabag✽`█geaigobadbcbkdcabcdaiadcbacakdcbdabag✽`█gbamgnbaddkdcdbecbkdcadbbag●`○aqglbadekccadccaiaccdbkccadbbag☉`~"
lose_qiewin2="`ツ`ygbamgnbaddkdcdbecbkdcadbbag●`○aqglbadekccadccaiaccdbkccadbbag☉`~argkbadekccaddiadekccadbbag☉`~asgjbadekccaddiadekccadbbag웃`}aughbadekccaddiadekccadbbag⌂`|avggbadekdcadciadekccadbbagjlegblcgv`|awgfbadekdcadciadekccadahcghllgv`{axgcbedckdcadciahfkbcahegglbgcldgalbgw`zazgabacdbddakbcadchhbahccahbgglbgclcgblbgw`za{bacebanbbedbhbbchfcbhbggldbalbmabblbgw`za{bacebandbacbbbhccdhdcahcggbalfmblcgx`ya{bacebandbacehccdhbcahcgebcmcldmaldbbgw`xa{bbcdbandbacfhccbhfgdbbmglimabbgu`xa|bfndbacghccahebbgcbamcbbljmebbgt`wa|baccbbndbachhgicbemblfmclebamcbagt`wa|bacdbandbecabchfidhebclbmabbmdbaldmcbagu`va|bacdbandbfhiiahfidbalbmcbamabbmblcmcbagu`cah`ka|bacdbanabdidhoifbalbmcfabamdlcaabbgwan`ga|bacdbanabailhjifbalbmcfabamdlcaamabaguar`ea|bacdbanabaifdbjahfiajbheiebalbbbmafamabdlcmbbagsav`ca}baccbanabaifhejbiajbddhcicbblcmbbcmdlcmabagsajgfah`ba}baccbanabaifhdiadcjadaidhcbciabalcmcfabamdlbmbbagrajgiag`aa}bacdbdidhdidjadaidhcdbibbalcmcfabamclcmbbagqajgkaga}bacdbanbbehdidjadaiabchcdaicbalcmcfabamclcmabbgqaigmaf`テ`テ"
lose_qiewin3="`ツ`ya{bccdbanbbaddhdidbcdchcdaicbalcmcfabamclcmabegnaggoaagcabaybbkbbacdbanbbaicdahddabcjadbichcdaicbalcmcfabamclcmabahdbbgkafgvaaaybakcbacdbancbaichdddjadaidhcdaicbblbmcfabamclcbbhcbcgkacgmabggiagcazbakbbacdbancbaichddaicjadaidhcdaicbahabcmbfabamclabbjahbbbhbbagkabgmaagbaageicgbazbakcbencbaidhcdaicjadaidhcdaibbbjdbdmabcjehdbagkaagmaagaabgaaagcib`aiagbgbaxbckbicbeidhddaibjadaidhcdaibbajdbahbbchcdajehcbagkaagmaagaabgaaagbib`biagbgcawbakbbbjciakcbaidhddaibjadaidhcdaibbajcdahabbhfbbjdhcbagkaagnaagbaagbib`ciagbgdavbakcibjbbeidhddaibjadaidhcdaibbajcdahcbbhbbbhadajdhabbglaagfabggabgbib`diagbgdavbakciajaidkbbbichddaibjadaidhcdaibbajcdahebbhcdajdbadabaglaageaagbaagcibgcic`bba`biagbgdaqbbadbakciajciakcbaichddaibjadaidhcdaibbajcbbhidajbiabadahabaglaagdaagaabgaaagaih`bbb`aibgbgaarbblbbbabbakciajciakcbaichddaibjadaidhcdaibbaiajbdbbbhgbajaibdahbbaglaagdaagaabgaaagaig`bbc`aiagcaqbbhalchbbckciajciakbbcibhddaibjadaidhcbdichbdbbbhcbbdaibjahcbaglaageaagbaagaig`bbc`aibgcaobbhhmalabckaiajciabbnabciahddaibjadaidbfhbichcdbbcdbhaiajbhcbagmaageabgaibjaic`cbc`aibgdambbldhemaldfabbjbbbnfbdhadaibjadaibbenbbahbjchedchbjdhcbagmaaghiajcia`dbc`aibgdalbafbldhglafbmalabajabancbcnacebdjaiabcacnbbbhbjchfdahcjdhbbagnaagaibgcidja`ebc`aicgdalbambfbhdmalahemalbbajabanfcaadbandbcabccnbbbhbjchfdahcjdhbbaggfgaagaiabaid`fbe`aicgeambalamahdmalbfbhclcbajabbnecenabdhbnbcdbchcjchfdahcjchcbafnaagbiaba`aba`abd`abe`aidgeambalbhcmafcmbhclbbbjabcndcendoahancccaahbbbhbjchfdahcjchcbafoaagbiabh`abdidfageambalbhclamdlahclbbaiajbbanabdcendoahanabacbabcanbbaaabbjchfdahcjchabbfpaagcibbjidfagafagdambalbhclcmblahclbbaiajbbanbhcadbbncoabbhbaaccnbbaacbbjahfdahcjcbafraagdiebeidfagafageambalbhclcmblahclbbaiajbbanecehabdhbnbcdnbbaaebbhedahcjabbfsaagfifbaidfagafagafagdgaalbalbhclcmblahclbbenecenahcoahanccdnbbaagbbhcdahbbbfvaagifagaicgafagafagafagegcajbalbhclcmblahclbbaacbbndcendoahanccdnbbaaibbhadabbfxaagjfagafagafagafagafagfgeahbalbhclcmblahclbbaadbandcendoahanccdnbbafgadbbfzaagkfagafagafagafagg`テ`テ"
lose_qiewin4="`ツ`yggafbalbhclcmblahclbbaadbandcendoahanccdnbbaf♥aaglfagafagafaghghaebblahclcmblahcbbaebandcendoahanccdnbbaf☉aagxgefeaebbhblcmblahbbaagbandcendoahanccdbbf웃aagxgafladbclbmblabbahbandcendoahancccbaf😐aagwfqacbeaafdaebcnbcendoahanccabbftaxfaaagwfuadfkabbecbndoahanccafia♥gwf웃abbfoahanabbfia♥gx`af🅾️abbcfka♥gx`cfえa●gx`efうa✽gx`gfいa░gx`ifあa🐱gy`kf▥a▒gy`mf▤a█gy`pf❎avffaagz`rf▤aqfhaagz`tf▤amfjaagz`wf▥affmaagz`zfそaag{`▒fくaag{`◆f⧗aag{`テ`gga`oga`を`fgc`mgc`ふga`o`テ`テ"
lose_qiewin5="`ツ`y`ggc`kgc`ふgc`n`hgc`igc`⬅️gb`웃gc`n`hgc`hgc`sga`wgc`웃gc`n`igc`fgc`sgc`vgc`|ge`hgc`n`jgc`dgc`ggd`igc`jga`kgc`jge`lgg`fgc`cgc`i`kgc`bgc`fgg`ggc`jgc`kgc`ggh`jgg`egl`h`kgc`agc`fgi`fgc`ige`jgc`fgj`hgc`igl`i`lge`fgd`dgc`egc`igd`kgc`fgd`dgc`fgc`kgh`l`mgc`ggc`egc`egc`igd`kgc`fgc`fgc`egc`mgc`o`mgc`ggc`fgc`dgc`igc`lgc`fgc`ggc`egc`lgc`o`mgc`ggc`fgc`cgc`jgc`lgc`fgc`ggc`fgc`kgc`o`mgc`ggc`fgc`cgc`igd`lgc`ggc`fgc`ggc`kgc`n`mgc`ggc`egc`egc`gge`mgc`fgc`fgc`hgc`jgc`fga`g`lgc`hgc`bge`fgc`fgc`agc`lgc`ggc`dgd`igc`igc`egc`f`lgc`igh`hgc`dgc`bgd`kgd`ggi`kgc`igc`dgc`f`lgc`jgf`jgh`dgd`kgc`agb`egg`hgh`hgc`cgc`g`lgc`kgb`ngf`fgc`kgf`fge`hgh`jgg`h`lgc`|gd`hga`mgd`ugf`lge`i`lgc`❎gb`wgb`pgc`j`lgb`オ`テ`テ`テ`テ`テ`テ"

dirx={-1,-1,0,1,1,1,0,-1}
debug =""
debug1=""
qiqiu_c={2,3,4,8,9,10,11,12,14} --气球颜色

function _init()
	startgame()
end

function _update()
	_upd()
end
function _draw()
	_dra()
    --print(qie.findgifts,1,1,7)
    --print(#giftpackage.gifts_t)
    --print(qie.transgifts)
    --print(#qie.trans_gifts_table)
    --print(#gifts_ground)
end

function startgame()--游戏开始的设置
    gamestartset()
	_upd=update_menu
	_dra=draw_menu
end

function gamestartset()
    blinkt=0
    gametime=0
    --烟雾
    smooke={} 
    for i=0,3 do
    add(smooke,
        {x=72,
        y=100+i*5,
        r=1,
        spd=rnd(0.4)+0.05,
        frame=1,
        angle=rnd(3.14*2), -- 随机初始角度
        spr={6,13,5,1}})
    end
    --雪
    snow={}
    for i=1,50 do
        add(snow,
        {x=rnd(128),
        y=rnd(128),
        spd=rnd(0.7),
        w=rnd(2), --左右摇摆速度
        c=6+rnd(2)/1})--6/7，让雪花更有层次
    end

    --礼物袋
    giftpackage={spr={32,34,36,38},x=56,y=108,gifts_t={}}
    bullets={}
    ui_c=0
    time_c=0
    gifts={}--礼物
    gifts_ground={}--地上的礼物
    gifts_trans ={}--搬运的礼物
    trans_num_timer=0--计数器
    gifts_spr_t={64,65,66,67,68,69,70,71,72} --礼物的精灵的表(table)
    for i=0,7 do
        add(gifts,{
            x=5+rnd(100),
            y=-rnd(40),
            long=max(20,flr(rnd(30))),
            spr=rnd(gifts_spr_t),
            spd=rnd(0.3)+0.02,
            c=rnd(qiqiu_c),
            mode="down",
            expspr_t=0})
    end
    -------------------------player-------------------
    p={x=54,
        y=111,
        run_spd=1,
        trans_spd=0.2,
        sspr={
            idle={8,2,8,14},
            shoot={16,1,9,15},
            run={{25,2,10,14},{35,2,10,14},{45,2,8,14},{53,2,8,14}},
            trans={{61,2,10,14},{71,2,10,14},{81,2,10,14}}
        },
        allstate={idle="idle",
            shoot = "shoot",
            run = "run",
            trans = "trans"},
        spdx=0
        }
    p.dire=0
    p.last_dire=0
    p.is_shoot=false
    p.isaddbullet=false
    p.shoot_t=0
    p.is_trans=false
    p.can_trans=true
    p.isgitfsdown=false --是否放下了礼物进礼物袋
    p.state=p.allstate.idle
    --企鹅
    qie={
        x=-8,
        y=114,
        run_spd=1,
        trans_spd=0.35,
        escape_spd=1.5,
        sspr={
            hide={0,0,0,0},
            look={125,64,3,7},
            run={{0,64,10,6},{11,64,11,6},{23,64,12,6},{36,64,15,6},{36,64,15,6},{36,64,15,6},{36,64,15,6}},
            find={{16,70,8,10},{24,70,9,10},{33,73,7,7},{39,73,7,7}},
            trans={{0,70,8,10},{8,70,8,10}},
            fright={{105,69,10,11},{115,69,10,11}},
            escape={{0,64,10,6},{11,64,11,6},{23,64,12,6},{36,64,15,6},{36,64,15,6},{36,64,15,6},{36,64,15,6}}
        },
        allstate={
            hide="hide", --隐藏
            look="look",--观察
            run="run", --移动
            find="find",--查找
            trans="trans",--搬运
            fright="fright",--惊吓
            escape="escape"--逃跑
        }
    }
    qie.state=qie.allstate.hide
    qie.frame=0
    qie.dire=1 --默认为左
    qie.hidelook_t=0 --暗中观察的时间
    qie.look_t=0 --当面观察的时间
    qie.isclose=false --是否被靠近
    qie.find_t=0
    qie.fright_t=0
    qie.findgifts=0 --弄到的礼物数量
    qie.transgifts=0 --搬运的礼物数量
    qie.trans_gifts_table={} --搬运礼物的组
end




